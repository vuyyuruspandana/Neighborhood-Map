ABOUT:

This project is a single page application which uses Goople Maps API to display the map and the markers. Four Square Api is used to load the location details.

How To?
 Download the files and open neighbourhood.html file

